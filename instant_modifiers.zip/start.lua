mod_metadata("name", "Instant Modifiers")
mod_metadata("author", "2MuchDiscord")
mod_metadata("version", "1.0.0")

local function patch_game_rules(document)
    document:set("/bloon_send_round_unlock_regen", 1)
    document:set("/bloon_send_round_unlock_camo", 1)
    document:set("/bloon_send_round_unlock_fortified", 1)
end

jet_json_advanced_patch("game_data/game_project/assets/data/default.gamerules", patch_game_rules)
jet_json_advanced_patch("game_data/game_project/assets/data/default_private.gamerules", patch_game_rules)
