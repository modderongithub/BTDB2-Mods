mod_metadata("name", "Remove Modifiers")
mod_metadata("author", "2MuchDiscord")
mod_metadata("version", "1.0.0")

local function patch_game_rules(document)
    document:set("/disable_camo_bloon_send", true)
    document:set("/disable_regen_bloon_send", true)
    document:set("/disable_fortified_bloon_send", true)
end

jet_json_advanced_patch("game_data/game_project/assets/data/default.gamerules", patch_game_rules)
jet_json_advanced_patch("game_data/game_project/assets/data/default_private.gamerules", patch_game_rules)
